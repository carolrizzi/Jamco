
document.write("<script type='text/javascript' src='js/defaultScenarios.js'></script>");

// === IMAGES === //
var IMAGE_DIR = "image/";
var CAR_IMAGE = IMAGE_DIR + "bus.png";
var START_IMAGE = IMAGE_DIR + "start.png";
var ARRIVE_IMAGE = IMAGE_DIR + "arrive.png";
var SLUG_IMAGE = IMAGE_DIR + "slug.png"
var F1_IMAGE = IMAGE_DIR + "f1.png";
var SLUG_SIGN_IMAGE = IMAGE_DIR + "slug_road_sign.png";
var RABBIT_SIGN_IMAGE = IMAGE_DIR + "rabbit_road_sign.png";

// === CONSTANTS === //
var MAP;
var HOST = "http://localhost:8000";

// === SHARED === //
var MARKERS = [];
var SCENARIOS = defScenarios;

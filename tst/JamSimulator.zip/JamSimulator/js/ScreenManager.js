
document.write("<script type='text/javascript' src='js/globals.js'></script>");
document.write("<script type='text/javascript' src='js/util.js'></script>");

var ScreenManager = function () {
	p = {};

	MAP = new google.maps.Map(document.getElementById("map"), {
		center: new google.maps.LatLng(-20.27, -40.30),
		zoom: 14, //0,7 and 18
		mapTypeId: google.maps.MapTypeId.ROADMAP
	});

	var screens = {
		mainMenu: document.getElementById('main_menu'),
		create: document.getElementById('create'),
		save: document.getElementById('save'),
		run: document.getElementById('run'),
		import: document.getElementById('import'),
		export: document.getElementById('export'),
		list: document.getElementById('list')
	}

	p.showMainMenuFromCreateScenario = function () {

		var response = confirm('The current scenario was not saved. Proceed anyway?');
		if(response){
			p.showMainMenu();
		}
	}

	p.showMainMenu = function () {
		cleanMarkers();
		screens.mainMenu.style.display = 'inline';
		screens.create.style.display = 'none';
		screens.save.style.display = 'none';
		screens.run.style.display = 'none';
		screens.import.style.display = 'none';
		screens.export.style.display = 'none';
		screens.list.style.display = 'none';
	}

	p.showCreateScenario = function () {
		cleanMarkers();
		screens.mainMenu.style.display = 'none';
		screens.create.style.display = 'inline';
		screens.save.style.display = 'none';
		screens.run.style.display = 'none';
		screens.import.style.display = 'none';
		screens.export.style.display = 'none';
		screens.list.style.display = 'none';
	}

	p.showSaveScenario = function () {
		cleanMarkers();
		screens.mainMenu.style.display = 'none';
		screens.create.style.display = 'none';
		screens.save.style.display = 'inline';
		screens.run.style.display = 'none';
		screens.import.style.display = 'none';
		screens.export.style.display = 'none';
		screens.list.style.display = 'none';
	}

	p.showRunScenario = function () {
		cleanMarkers();
		screens.mainMenu.style.display = 'none';
		screens.create.style.display = 'none';
		screens.save.style.display = 'none';
		screens.run.style.display = 'inline';
		screens.import.style.display = 'none';
		screens.export.style.display = 'none';
		screens.list.style.display = 'none';
	}

	p.showImportScenario = function () {
		cleanMarkers();
		screens.mainMenu.style.display = 'none';
		screens.create.style.display = 'none';
		screens.save.style.display = 'none';
		screens.run.style.display = 'none';
		screens.import.style.display = 'inline';
		screens.export.style.display = 'none';
		screens.list.style.display = 'none';
	}

	p.showExportScenario = function () {
		cleanMarkers();
		screens.mainMenu.style.display = 'none';
		screens.create.style.display = 'none';
		screens.save.style.display = 'none';
		screens.run.style.display = 'none';
		screens.import.style.display = 'none';
		screens.export.style.display = 'inline';
		screens.list.style.display = 'none';
	}
	
	p.showListVehicles = function () {
		cleanMarkers();
		screens.mainMenu.style.display = 'none';
		screens.create.style.display = 'none';
		screens.save.style.display = 'none';
		screens.run.style.display = 'none';
		screens.import.style.display = 'none';
		screens.export.style.display = 'none';
		screens.list.style.display = 'inline';
	}

	p.showMainMenu();

	return p;
}
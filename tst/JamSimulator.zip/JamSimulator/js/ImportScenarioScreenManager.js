
document.write("<script type='text/javascript' src='js/globals.js'></script>");

var ImportScenarioScreenManager = function () {
	var p = {};

	var code = document.getElementById('import_code');

	var importScenarios = function (clean) {
		var toParse = code.value;
		if(toParse == null || toParse === ''){
			alert('Invalid scenario code.');
			return false;
		}
		var obj = JSON.parse(toParse);

		if(clean) SCENARIOS = obj;
		else {
			obj.forEach(function(scenario){
				SCENARIOS.push(scenario);//Scenario(scenario));
			});
		}
		code.value = '';
		alert('Scenario imported.');
	}

	p.onStartScreen = function () {
		code.value = '';
	}

	p.onCleanAndImportScenariosClick = function () {
		importScenarios(true);
	}

	p.onImportScenariosClick = function () {
		importScenarios(false)
	}

	return p;
}
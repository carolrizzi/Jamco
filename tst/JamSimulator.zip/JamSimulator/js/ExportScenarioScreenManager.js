
document.write("<script type='text/javascript' src='js/globals.js'></script>");

var ExportScenarioScreenManager = function () {
	var p = {};

	var code = document.getElementById('export_code');

	p.onStartScreen = function () {
		code.value = JSON.stringify(SCENARIOS, null, '    ');
	}

	return p;
}
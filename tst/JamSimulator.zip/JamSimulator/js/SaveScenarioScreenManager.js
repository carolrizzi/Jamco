
document.write("<script type='text/javascript' src='js/globals.js'></script>");

var SaveScenarioScreenManager = function () {
	var p = {};
	var vehicles;
	var callback;

	var scenarioHTML = {
		name: document.getElementById('save_scenario_name_input'),
		description: document.getElementById('save_scenario_description_input')
	}

	p.onStartScreen = function (aVehicles, aCallback) {
		scenarioHTML.name.value = '';
		scenarioHTML.description.value = '';
		vehicles = aVehicles;
		callback = aCallback;
	}

	p.onSaveClick = function () {
		var name = scenarioHTML.name.value;
		if(name === '') {
			alert('Provide the scenario name.');
			return false;
		}else{
			SCENARIOS.push({//new Scenario({
				name: name,
				description: scenarioHTML.description.value,
				vehicles: vehicles
			});//);
			alert('Scenario ' + name + 'was saved.');
			callback();
		}
	}

	return p;
}
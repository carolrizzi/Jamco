
document.write("<script type='text/javascript' src='js/Scenario.js'></script>");
document.write("<script type='text/javascript' src='js/globals.js'></script>");

var RunScenarioScreenManager = function () {
	
	var p = {};

	var currentScenario;

	var scenarioHTML = {
		list: document.getElementById('run_scenarios'),
		description: document.getElementById('run_description'),
		run: document.getElementById('run_run_button'),
		del: document.getElementById('run_delete_button'),
		stop: document.getElementById('run_stop_button'),
		mainMenu: document.getElementById('run_main_menu_button')
	}

	var setButtonsEnabling = function (isScenarioRunning) {
		scenarioHTML.list.disabled = isScenarioRunning;
		scenarioHTML.run.disabled = isScenarioRunning;
		scenarioHTML.del.disabled = isScenarioRunning;
		scenarioHTML.stop.disabled = !isScenarioRunning;
		scenarioHTML.mainMenu.disabled = isScenarioRunning;
	}

	p.onStartScreen = function () {
		var select = scenarioHTML.list;
		select.options.length = 0;

		for (var i = 0; i < SCENARIOS.length; i++) {
		    select.options.add(new Option(SCENARIOS[i].name, i));
		}

		scenarioHTML.description.value = SCENARIOS[0].description;
		setButtonsEnabling(false);
	}

	p.onRunScenarioClick = function () {
		setButtonsEnabling(true);
		currentScenario = new Scenario(SCENARIOS[scenarioHTML.list.selectedIndex]);
		// currentScenario = SCENARIOS[scenarioHTML.list.selectedIndex];
		currentScenario.run(function () {
			setButtonsEnabling(false);
			currentScenario = null;
		});
	}

	p.onStopScenarioClick = function () {
		currentScenario.stop();
		currentScenario = null;
		setButtonsEnabling(false);
	}

	p.onDeleteScenarioClick = function () {
		var removed = SCENARIOS.splice(scenarioHTML.list.selectedIndex, 1);
		alert('Scenario "' + removed[0].name + '" was deleted.');
		p.onStartScreen();
	}

	p.onScenariosListChange = function () {
		scenarioHTML.description.value = SCENARIOS[scenarioHTML.list.selectedIndex].description;
	}

	p.getCurrentScenario = function () {
		return SCENARIOS[scenarioHTML.list.selectedIndex];
	}

	p.setVehicles = function (changedVehicles) {
		SCENARIOS[scenarioHTML.list.selectedIndex].vehicles = changedVehicles;
	}

	return p;
}
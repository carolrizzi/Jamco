
document.write("<script type='text/javascript' src='js/globals.js'></script>");
document.write("<script type='text/javascript' src='js/NotificationService.js'></script>");

var ParkedVehicle = function (vehicle, onEnd) {
	
	var p = {};

	var marker; 
	var stop = false;
	var service;

	p.getInfo = function () {
		return {
			// id: vehicle.id,
			lat: vehicle.start.lat,
			lng: vehicle.start.lng,
			speed: 0
		};
	}

	p.stop = function () {
		stop = true;
		service.stop();
		if(marker) marker.setMap(null);
	}

	var init = function () {
		marker = new google.maps.Marker({
			position: new google.maps.LatLng(vehicle.start.lat, vehicle.start.lng),
			map: MAP,
			title: "Name: " + vehicle.name + "\nPosition: (" + vehicle.start.lat + ", " + vehicle.start.lng + ")",
			icon: CAR_IMAGE
		});
		setTimeout(function(){
			if(stop)return;
			service.stop();
			marker.setMap(null);
			onEnd(p);
		}, vehicle.parkedDuration * 1000);
	}

	service = new NotificationService(p);
	init();
	service.run();

	return p;
}

document.write("<script type='text/javascript' src='js/globals.js'></script>");
document.write("<script type='text/javascript' src='js/util.js'></script>");

var ListVehiclesScreenManager = function () {
	var p = {};
	var vehicles;

	var trHTML =  {
		normalSpeed: document.getElementById('list_normal_speed_tr'),
		jamSpeed: document.getElementById('list_jam_speed_tr'),
		parkedDuration: document.getElementById('list_parked_duration_tr')
	}
	
	var vehicleHTML = {
		vehicles: document.getElementById('list_vehicles'),
		normalSpeed: document.getElementById('list_normal_speed_input'),
		jamSpeed: document.getElementById('list_jam_speed_input'),
		parkedDuration: document.getElementById('list_parked_duration_input'),
		situation: document.getElementById('list_situation'),
		save: document.getElementById('list_save_button'),
		del: document.getElementById('list_delete_button')
	}

	var scenarioHTML = {
		title_tr: document.getElementById('list_title_tr'),
		title_h: document.getElementById('list_title_h')
	}

	var placeMarker = function (vehicleName, coord, image) {
		var position = new google.maps.LatLng(coord.lat, coord.lng);

		var point = {
			position: position,
			map: MAP,
			title: 'Vehicle: ' + vehicleName + '\nPosition: ' + coord.toString(),
			icon: image
		}

		MARKERS.push(new google.maps.Marker(point));
	}

	var refreshSelector = function () {
		var select = vehicleHTML.vehicles;
		select.options.length = 0;

		for (var i = 0; i < vehicles.length; i++) {
		    select.options.add(new Option(vehicles[i].name, i));
		}
	}

	p.onStartScreen = function (scenario) {
		if(scenario.name == null || scenario.name === '') {
			scenarioHTML.title_tr.style.display = 'none';
		}else{
			scenarioHTML.title_tr.style.display = 'inline';
			scenarioHTML.title_h.innerHTML = scenario.name;
		}

		var disable = scenario.vehicles.length <= 0 ? true : false
		vehicleHTML.save.disabled = disable;
		vehicleHTML.del.disabled = disable;
		if(disable){
			cleanMarkers();
			vehicleHTML.situation.innerHTML = 'Not selected';
			trHTML.normalSpeed.style.visibility = 'hidden';
			trHTML.jamSpeed.style.visibility = 'hidden';
			trHTML.parkedDuration.style.visibility = 'hidden';
		}else{
			vehicles = scenario.vehicles;
			refreshSelector();
			p.onSelectedVehicleChange();
		}
	}

	p.onSelectedVehicleChange = function () {
		cleanMarkers();
		var selected = vehicles[vehicleHTML.vehicles.selectedIndex];
		var name = selected.name;

		if(selected.jamStart != null){
			vehicleHTML.situation.innerHTML = 'Traffic Jam';
			vehicleHTML.jamSpeed.value = selected.jamSpeed / 0.277777778;
			vehicleHTML.normalSpeed.value = selected.normalSpeed / 0.277777778;

			placeMarker(name, selected.start, START_IMAGE);
			placeMarker(name, selected.jamStart, SLUG_SIGN_IMAGE);
			placeMarker(name, selected.jamEnd, RABBIT_SIGN_IMAGE);
			placeMarker(name, selected.end, ARRIVE_IMAGE);

			trHTML.normalSpeed.style.visibility = 'visible';
			trHTML.jamSpeed.style.visibility = 'visible';
			trHTML.parkedDuration.style.visibility = 'hidden';
		
		}else if (selected.end != null){
			vehicleHTML.situation.innerHTML = 'Normal Traffic';
			vehicleHTML.normalSpeed.value = selected.normalSpeed / 0.277777778;
			
			placeMarker(name, selected.start, START_IMAGE);
			placeMarker(name, selected.end, ARRIVE_IMAGE);

			trHTML.normalSpeed.style.visibility = 'visible';
			trHTML.jamSpeed.style.visibility = 'hidden';
			trHTML.parkedDuration.style.visibility = 'hidden';		
		} else {
			vehicleHTML.situation.innerHTML = 'Parked';
			vehicleHTML.parkedDuration.value = selected.parkedDuration;
			placeMarker(name, selected.start, CAR_IMAGE);

			trHTML.normalSpeed.style.visibility = 'hidden';
			trHTML.jamSpeed.style.visibility = 'hidden';
			trHTML.parkedDuration.style.visibility = 'visible';
		}
	}

	p.onGoBackClick = function () {
		cleanMarkers();
		return vehicles;
	}

	p.onSaveClick = function () {
		var index = vehicleHTML.vehicles.selectedIndex;

		if(vehicleHTML.situation.innerHTML === 'Parked')
			vehicles[index].parkedDuration = parseInt(vehicleHTML.parkedDuration.value);

		else{
			vehicles[index].normalSpeed = parseFloat(vehicleHTML.normalSpeed.value) * 0.277777778;
			if(vehicleHTML.situation.innerHTML === 'Traffic Jam')
				vehicles[index].jamSpeed = parseFloat(vehicleHTML.jamSpeed.value) * 0.277777778;
		}

		alert('Vehicle "' + vehicles[index].name + '" was saved');
	}

	p.onDeleteClick = function () {
		var removed = vehicles.splice(vehicleHTML.vehicles.selectedIndex, 1);
		alert('Vehicle "' + removed[0].name + '" was deleted.');
		
		refreshSelector();
		p.onSelectedVehicleChange();
	}

	return p;
}
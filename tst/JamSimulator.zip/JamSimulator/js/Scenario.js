
document.write("<script type='text/javascript' src='js/globals.js'></script>");
document.write("<script type='text/javascript' src='js/util.js'></script>");
document.write("<script type='text/javascript' src='js/ParkedVehicle.js'></script>");
document.write("<script type='text/javascript' src='js/MovingVehicle.js'></script>");

var Scenario = function (info) {
	
	var p = {
		name: info.name,
		description: info.description,
		vehicles: info.vehicles
	};

	var OnTheRoad = function () {
		var pub = {};
		var v = [];
		var blocked = false;

		pub.pushVehicle = function (value) {
			if(!blocked){
				blocked = true;
					v.push(value);
				blocked = false;
			}else{
				setTimeout(pub.pushVehicle(value), 10);
			}
		}

		pub.removeVehicle = function (value) {
			if(!blocked){
				blocked = true;
					var index = v.indexOf(value);
					if(index != undefined) {
						v.splice(index, 1);
					}
					var l = v.length;
				blocked = false;
				return l;
			}else{
				setTimeout(pub.removeVehicle(value), 10);
			}
		}

		pub.removeAll = function () {
			if(!blocked){
				blocked = true;
					v.forEach(function(obj){
						obj.stop();
					});
					v = [];
				blocked = false;
			}else{
				setTimeout(pub.pushVehicle(value), 10);
			}
		}

		return pub;
	}

	var onTheRoad; // = new OnTheRoad ();

	p.run = function (onEnd) {
		onTheRoad = new OnTheRoad ();
		
		var onNaturalStop = function (v) {
			var size = onTheRoad.removeVehicle(v);
			console.log('SIZE: ' + size);
			if(size <= 0){
				console.log('ON_END CALL');
				onEnd();
			}
		}

		var startVehicles = function (j) {
			if(p.vehicles.length <= j) return;
			setTimeout(function() {
				// var connectedVehicle;
				
				if(p.vehicles[j].end == null){
					var parkedVehicle = new ParkedVehicle(p.vehicles[j], onNaturalStop);
					onTheRoad.pushVehicle(parkedVehicle);
				}else{
					new MovingVehicle(p.vehicles[j], onNaturalStop, onTheRoad.pushVehicle);
				}
				
				startVehicles(j+1);
		    }, 3000);
		}

		startVehicles(0);

		// p.vehicles.forEach(function(vehicle){
		// 	setTimeout(function() {
		// 		// var connectedVehicle;
				
		// 		if(vehicle.end == null){
		// 			var parkedVehicle = new ParkedVehicle(vehicle, onNaturalStop);
		// 			onTheRoad.pushVehicle(parkedVehicle);
		// 		}else{
		// 			new MovingVehicle(vehicle, onNaturalStop, onTheRoad.pushVehicle);
		// 		}
				
		//     }, 5000);
		// });
	}

	p.stop = function () {
		onTheRoad.removeAll();
	}

	return p;
}


document.write("<script type='text/javascript' src='js/util.js'></script>");
document.write("<script type='text/javascript' src='js/globals.js'></script>");

var NotificationService = function (vehicle) {

	var p = {};
	var stop  = false;
	// var id = vehicle.getInfo().id;
	var id;

	function sendMessage (url, fn, functionName) {
		try{
			var xmlhttp = makeHttpObject();
			xmlhttp.open("GET", url, true);
			xmlhttp.onreadystatechange = function () {
				var code = xmlhttp.readyState;
				if (xmlhttp.readyState != 4) return;
				if(xmlhttp.status != 200){
					//printErrorMessage(functionName, url, null, xmlhttp);
					return;
				}
				if(fn != null){
					id = xmlhttp.responseText;
					console.log("Id returned: " + id);
					fn();
				}
			}
			xmlhttp.send(null);
		} catch (e) {
			//printErrorMessage(functionName, url, e.message, null);
		}
	}

	p.stop = function () {
		stop = true;
		sendMessage(HOST + "/Jamco/disconnect?id=" + id, null, 'Notify.disconnect');
		console.log("Notification Service stoped. Id: " + id);
	}

	p.run = function () {
		var sendNotification = function (){
			if(stop) return;
			
			setTimeout(function() {
				if(stop) return;
				info = vehicle.getInfo();
				url = HOST + "/Jamco/update?id=" + id + "&lat=" + info.lat + "&lng=" + info.lng + "&speed=" + (info.speed/0.277777778);
				sendMessage(url, null, 'Notify.sendNotification');
				sendNotification();
			}, 10000);
		}

		var info = vehicle.getInfo();
		var url = HOST + "/Jamco/getid?lat=" + info.lat + 
									 "&lng=" + info.lng + 
									 "&speed=" + (info.speed/0.277777778);
		sendMessage(url, sendNotification, 'Notify.getId');

		// sendNotification();
	}

	return p;
}

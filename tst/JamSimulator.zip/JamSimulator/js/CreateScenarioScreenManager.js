
document.write("<script type='text/javascript' src='js/Scenario.js'></script>");
document.write("<script type='text/javascript' src='js/globals.js'></script>");
document.write("<script type='text/javascript' src='js/util.js'></script>");

var CreateScenarioScreenManager = function () {
	var p = {};
	var creationManager;
	var vehicles = [];
	var currentScenario;

	var trHTML =  {
		normalSpeed: document.getElementById('create_normal_speed_tr'),
		jamSpeed: document.getElementById('create_jam_speed_tr'),
		parkedDuration: document.getElementById('create_parked_duration_tr')
	}
	
	var vehicleHTML = {
		name: document.getElementById('create_vehicle_name_input'),
		normalSpeed: document.getElementById('create_normal_speed_input'),
		jamSpeed: document.getElementById('create_jam_speed_input'),
		parkedDuration: document.getElementById('create_parked_duration_input'),
		save: document.getElementById('create_save_vehicle_button'),
		clean: document.getElementById('create_clean_vehicle_button'),
		list: document.getElementById('create_list_vehicle_button'),
		situation: document.getElementById('create_vehicle_situation_select')
	}

	var scenarioHTML = {
		run: document.getElementById('create_run_scenario_button'),
		stop: document.getElementById('create_stop_scenario_button'),
		save: document.getElementById('create_save_scenario_button')
	}

	var mainMenu = document.getElementById('create_main_menu_button');

	var enableAll = function () {
		vehicleHTML.situation.disabled = false;
		vehicleHTML.name.disabled = false;
		vehicleHTML.jamSpeed.disabled = false;
		vehicleHTML.normalSpeed.disabled = false;
		vehicleHTML.parkedDuration.disabled = false;
		vehicleHTML.save.disabled = false;
		vehicleHTML.clean.disabled = false;
		vehicleHTML.list.disabled = false;

		scenarioHTML.run.disabled = false;
		scenarioHTML.stop.disabled = false;
		scenarioHTML.save.disabled = false;

		mainMenu.disabled = false;
	}

	var disableAll = function () {
		vehicleHTML.situation.disabled = true;
		vehicleHTML.name.disabled = true;
		vehicleHTML.jamSpeed.disabled = true;
		vehicleHTML.normalSpeed.disabled = true;
		vehicleHTML.parkedDuration.disabled = true;
		vehicleHTML.save.disabled = true;
		vehicleHTML.clean.disabled = true;
		vehicleHTML.list.disabled = true;

		scenarioHTML.run.disabled = true;
		scenarioHTML.stop.disabled = true;
		scenarioHTML.save.disabled = true;

		mainMenu.disabled = true;
	}

	var refreshInputs = function (restartName, restartSituation, restartInfo, restartButtons) {
		if(restartName) vehicleHTML.name.value = '';
		
		if(restartSituation) {
			vehicleHTML.situation.selectedIndex = 0;
			trHTML.normalSpeed.style.visibility = 'visible';
			trHTML.jamSpeed.style.visibility = 'visible';
			trHTML.parkedDuration.style.visibility = 'hidden';
		}

		if(restartInfo){
			vehicleHTML.jamSpeed.value = '10';
			vehicleHTML.normalSpeed.value = '50';
			vehicleHTML.parkedDuration.value = '60';
		}

		if(restartButtons){
			enableAll();
			if(vehicles.length <= 0) {
				scenarioHTML.run.disabled = true;
				scenarioHTML.save.disabled = true;
			}
			scenarioHTML.stop.disabled = true;
			vehicleHTML.save.disabled = true;
			vehicleHTML.clean.disabled = true;
		}
	}

	var refreshOnlyButtons = function () {
		refreshInputs(false, false, false, true);
	}

	var onVehicleCreationStart = function () {
		disableAll();
		vehicleHTML.clean.disabled = false;
		return {
			name: vehicleHTML.name.value,
			situation: vehicleHTML.situation.selectedIndex,
			normalSpeed: vehicleHTML.normalSpeed.value,
			jamSpeed: vehicleHTML.jamSpeed.value,
			parkedDuration: vehicleHTML.parkedDuration.value,
			onInvalidValues: function () {
				refreshOnlyButtons();
				// creationManager = new CreationManager(onVehicleCreationStart, onVehicleCreationEnd);
			}
		}
	}

	var onVehicleCreationEnd = function () {
		disableAll();
		vehicleHTML.clean.disabled = false;
		vehicleHTML.save.disabled = false;
	}

	p.onStartScreen = function () {
		vehicles = [];
		refreshInputs(true, true, true, true);
		creationManager = new CreationManager(onVehicleCreationStart, onVehicleCreationEnd);
	}

	p.onSaveVehicle = function () {
		var vehicle = creationManager.getVehicle();
		vehicles.push(vehicle);
		// creationManager.save(function(vehicle){
		// 	vehicles.push(vehicle);
			refreshInputs (true, false, false, true);
			cleanMarkers();
			creationManager = new CreationManager(onVehicleCreationStart, onVehicleCreationEnd);
		// });
	}

	p.onCleanVehicle = function () {
		cleanMarkers();
		creationManager = new CreationManager(onVehicleCreationStart, onVehicleCreationEnd);
		refreshOnlyButtons();
	}
	
	p.onRunScenarioClick = function () {
		disableAll();
		scenarioHTML.stop.disabled = false;
		currentScenario = new Scenario ({
			name: '',
			description: '',
			vehicles: vehicles
		});
		currentScenario.run(refreshOnlyButtons);
	}

	p.getCurrentScenario = function () {
		return {
			name: '',
			description: '',
			vehicles: vehicles
		}
	}

	p.setVehicles = function (changedVehicles) {
		vehicles = changedVehicles;
	}
 
	p.onStopScenarioClick = function () {
		currentScenario.stop();
		refreshOnlyButtons();
	}

	p.onVehicleSituationChange = function () {
		switch(vehicleHTML.situation.selectedIndex)
		{
			case 0: //Traffic Jam
				trHTML.normalSpeed.style.visibility = 'visible';
				trHTML.jamSpeed.style.visibility = 'visible';
				trHTML.parkedDuration.style.visibility = 'hidden';
				break;

			case 1: //Normal Traffic
				trHTML.normalSpeed.style.visibility = 'visible';
				trHTML.jamSpeed.style.visibility = 'hidden';
				trHTML.parkedDuration.style.visibility = 'hidden';
				break;

			case 2: //Parked
				trHTML.normalSpeed.style.visibility = 'hidden';
				trHTML.jamSpeed.style.visibility = 'hidden';
				trHTML.parkedDuration.style.visibility = 'visible';
				break;
		}
	}

	p.getVehicles = function () {
		return vehicles;
	}

	return p;
}

document.write("<script type='text/javascript' src='js/CreationManager.js'></script>");
document.write("<script type='text/javascript' src='js/ScreenManager.js'></script>");
document.write("<script type='text/javascript' src='js/CreateScenarioScreenManager.js'></script>");
document.write("<script type='text/javascript' src='js/RunScenarioScreenManager.js'></script>");
document.write("<script type='text/javascript' src='js/SaveScenarioScreenManager.js'></script>");
document.write("<script type='text/javascript' src='js/ImportScenarioScreenManager.js'></script>");
document.write("<script type='text/javascript' src='js/ExportScenarioScreenManager.js'></script>");
document.write("<script type='text/javascript' src='js/ListVehiclesScreenManager.js'></script>");

var screenManager;
var csManager;
var rsManager;
var ssManager;
var isManager;
var esManager;

function initialize () {
	screenManager = new ScreenManager();
	csManager = new CreateScenarioScreenManager();
	rsManager = new RunScenarioScreenManager();
	ssManager = new SaveScenarioScreenManager();
	isManager = new ImportScenarioScreenManager();
	esManager = new ExportScenarioScreenManager();
	lvManager = new ListVehiclesScreenManager();
	initMapListeners();
}

// ====================================================================== //
// SCREENS CHANGE
// ====================================================================== //

var currentScreen = '';
var currentManager;

function showCreateScenario () {
	currentScreen = 'showCreateScenario';
	currentManager = csManager;
	screenManager.showCreateScenario();
	csManager.onStartScreen();
}

function showRunScenario () {
	currentScreen = 'showRunScenario';
	currentManager = rsManager;
	screenManager.showRunScenario();
	rsManager.onStartScreen();
}

function showSaveScenario () {
	screenManager.showSaveScenario();
	ssManager.onStartScreen(csManager.getVehicles(), screenManager.showMainMenu);
}

function showImportScenario () {
	screenManager.showImportScenario();
	isManager.onStartScreen();
}

function showExportScenario () {
	screenManager.showExportScenario();
	esManager.onStartScreen();
}

function showMainMenu () {
	screenManager.showMainMenu();
}

function showMainMenuFromCreateScenario () {
	screenManager.showMainMenuFromCreateScenario();
}

function onListVehiclesClick () {
	screenManager.showListVehicles();
	lvManager.onStartScreen(currentManager.getCurrentScenario());
}

function onGoBackClick_List () {
	eval('screenManager.' + currentScreen + '()');
	currentManager.setVehicles(lvManager.onGoBackClick());
}

// ====================================================================== //
// CREATION SCENARIO SCREEN
// ====================================================================== //

function onVehicleSituationChange () {
	csManager.onVehicleSituationChange();
}

function onSaveVehileClick () {
	csManager.onSaveVehicle();
}

function onCleanVehicleClick () {
	csManager.onCleanVehicle();
}

function onRunScenarioClick () {
	csManager.onRunScenarioClick();
}

function onStopScenarioClick () {
	csManager.onStopScenarioClick();
}

// ====================================================================== //
// SAVE SCENARIO SCREEN
// ====================================================================== //

function onSaveScenarioClick () {
	ssManager.onSaveClick();
}

// ====================================================================== //
// RUN SCENARIO SCREEN
// ====================================================================== //

function onSelectedScenarioChange () {
	rsManager.onScenariosListChange();
}

function onRunScenarioClick_Run () {
	rsManager.onRunScenarioClick();
}

function onStopScenarioClick_Run () {
	rsManager.onStopScenarioClick();
}

function onDeleteScenarioClick () {
	rsManager.onDeleteScenarioClick();
}

// ====================================================================== //
// IMPORT SCENARIO SCREEN
// ====================================================================== //

function onCleanAndImportClick () {
	isManager.onCleanAndImportScenariosClick();
}

function onKeepAndImportClick () {
	isManager.onImportScenariosClick();
}

// ====================================================================== //
// LIST VEHICLES SCREEN
// ====================================================================== //

function onSelectedVehicleChange_List () {
	lvManager.onSelectedVehicleChange();
}

function onSaveVehicleClick_List () {
	lvManager.onSaveClick();
}

function onDeleteVehicleClick_List () {
	lvManager.onDeleteClick();
}

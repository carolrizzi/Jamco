
document.write("<script type='text/javascript' src='js/globals.js'></script>");
document.write("<script type='text/javascript' src='js/calc.js'></script>");
document.write("<script type='text/javascript' src='js/NotificationService.js'></script>");

var DIRECTION = new google.maps.DirectionsService();
var TRAVEL_MODE = google.maps.TravelMode.DRIVING;

var MovingVehicle = function (vehicle, onEnd, onStart) {
	
	var p = {};

	var position = {
		lat: vehicle.start.lat,
		lng: vehicle.start.lng,
		speed: vehicle.normalSpeed
	};

	var marker = {
		setMap: function () {}
	}; 
	var currentPath = {};
	var currentSubPath = {};
	var stop = false;
	var service;

	p.getInfo = function () {
		return position;
	}

	p.stop = function () {
		stop = true;
	}

	var buildCompletePath = function () {
		var steps;
		if(vehicle.jamStart){
			steps = {
						orig: vehicle.jamEnd, 
						dest: vehicle.end, 
						speed: vehicle.normalSpeed, 
						image: CAR_IMAGE,
						next: {
							orig: vehicle.jamStart, 
							dest: vehicle.jamEnd, 
							speed: vehicle.jamSpeed, 
							image: SLUG_IMAGE, 
							next: {
								orig: vehicle.start, 
								dest: vehicle.jamStart, 
								speed: vehicle.normalSpeed, 
								image: CAR_IMAGE, 
								next: null
							}
						}
					}
		}else{
			steps = {
				orig: vehicle.start, 
				dest: vehicle.end, 
				speed: vehicle.normalSpeed, 
				image: CAR_IMAGE,
				next: null
			}
		}
		return steps;
	}

	var steps = buildCompletePath();

	var initSubPath = function (orig, dest, speed, next) {
		var iter = Math.ceil(calcDistance(orig, dest) / speed);
		return {
			iter: iter,
			orig: orig,
			distLat: (dest.lat() - orig.lat()) / iter,
			distLng: (dest.lng() - orig.lng()) / iter,
			next: next
		};
	}

	// var move = function () {
	// 	var sec = 0;
	// 	var index = 1;
	// 	while (true){
	// 		if(index > currentSubPath.iter) {
	// 			currentSubPath = currentSubPath.next;
	// 			if(currentSubPath == null){
	// 				currentPath = currentPath.next;
	// 				if(currentPath){
	// 					position.speed = currentPath.speed;
	// 					currentSubPath = currentPath.subPath;
	// 					move(1);
	// 				}else{
	// 					service.stop();
	// 					onEnd(p);
	// 					marker.setMap(null);
	// 				}
	// 				return;
	// 			}
	// 			move(1);
	// 			return;
	// 		}
	// 		setTimeout(function(){
	// 			if(stop)return;
	// 			var lng = currentSubPath.orig.lng() + (index * currentSubPath.distLng);
	// 			var lat = currentSubPath.orig.lat() + (index * currentSubPath.distLat);
	// 			position.lat =  lat;
	// 			position.lng = lng;
	// 			marker.setMap(null);
	// 			marker = new google.maps.Marker({
	// 				position: new google.maps.LatLng(lat, lng),
	// 				map: MAP,
	// 				title: "Name: " + vehicle.name + "\nPosition: (" + lat + ", " + lng + ")",
	// 				icon: currentPath.image
	// 			});
	// 		}, 1000 * sec);
	// 		sec++;
	// 	}
	// }

	var move = function (index) {
		if(index > currentSubPath.iter) {
			currentSubPath = currentSubPath.next;
			if(currentSubPath == null){
				currentPath = currentPath.next;
				if(currentPath){
					position.speed = currentPath.speed;
					currentSubPath = currentPath.subPath;
					move(1);
				}else{
					service.stop();
					onEnd(p);
					marker.setMap(null);
				}
				return;
			}
			move(1);
			return;
		}

		setTimeout(function(){
			if(stop){
				service.stop();
				marker.setMap(null);
				return;
			}
			var lng = currentSubPath.orig.lng() + (index * currentSubPath.distLng);
			var lat = currentSubPath.orig.lat() + (index * currentSubPath.distLat);
			position.lat =  lat;
			position.lng = lng;
			marker.setMap(null);
			marker = new google.maps.Marker({
				position: new google.maps.LatLng(lat, lng),
				map: MAP,
				title: "Name: " + vehicle.name + "\nPosition: (" + lat + ", " + lng + ")",
				icon: currentPath.image
			});
			move(index + 1);
		}, 1000);
	}

	var initAndMove = function (step, next) {
		if(!step) {
			currentPath = next;
			currentSubPath = currentPath.subPath;
			console.log(vehicle.name + " path/subpath:", currentPath, currentSubPath);
			onStart(p);
			service = new NotificationService(p);
			service.run();
			move(1);
			return;
		}

		console.log(vehicle.name + " step/next:", step, next);

		var request = {
			origin: new google.maps.LatLng(step.orig.lat, step.orig.lng),
			destination: new google.maps.LatLng(step.dest.lat, step.dest.lng),
			travelMode: TRAVEL_MODE
		};

		var brk = false;
			// console.log('1');
		setTimeout(function(){brk = true;}, 10000);

			// console.log('2');
		var getDirections = function(){
			// console.log('3');
			setTimeout(function(){
				// console.log('BRK: ' + brk);
				if (brk) return; //status != google.maps.DirectionsStatus.OK && !brk) {
				// console.log('ENTERING DIRECTIONS');
				DIRECTION.route(request, function(response, status) {
					// console.log('INSIDE DIRECTIONS');
					if(status == google.maps.DirectionsStatus.OK){
						var overview_path = response.routes[0].overview_path;

						var length = overview_path.length;
						var path = initSubPath(overview_path[length - 2], overview_path[length - 1], step.speed, null);
						for (var i = length - 2; i > 0; i--){
							path = initSubPath(overview_path[i-1], overview_path[i], step.speed, path);
						}

						// console.log('CALLING INIT_AND_MOVE');
						initAndMove(step.next, {
							speed: step.speed,
							image: step.image,
							next: next, 
							subPath: path
						});
					}else{
						console.log(vehicle.name + ' - GOOGLE NAO FOI COM A MINHA CARA!');
						getDirections();
					}
				});
			}, 100);
		}

		getDirections();
	}

	initAndMove(steps, null);

	return p;
}
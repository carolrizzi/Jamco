
document.write("<script type='text/javascript' src='js/globals.js'></script>");

function doNothing () {}

function makeHttpObject() {
	try {return new XMLHttpRequest();}
	catch (error) {}
	try {return new ActiveXObject("Msxml2.XMLHTTP");}
	catch (error) {}
	try {return new ActiveXObject("Microsoft.XMLHTTP");}
	catch (error) {}

	throw new Error("Could not create HTTP request object.");
}

function printErrorMessage (func, url, msg, http) {
	var txt = "ERROR [" + func + "]";
	txt += "\nURL: " + url;
	if(http){
		txt += "\nReady State: " + http.readyState;
		txt += "\nStatus Code: " + http.status;
	}
	if(msg){
		txt += "\nError Message:</br>" + msg;
	}
	alert(txt);
}

function cleanMarkers () {
	MARKERS.forEach(function(marker){
		marker.setMap(null);
	});
}



document.write("<script type='text/javascript' src='js/globals.js'></script>");
document.write("<script type='text/javascript' src='js/calc.js'></script>");

var doNothing = function () {}
var processVehicle = doNothing;

var initMapListeners = function () {
	google.maps.event.addListener(MAP, 'click', function(event) {
		// var tr = document.getElementById('test');
		// tr.style.visibility = 'visible'
		// tr.innerHTML += event.latLng.toString();
		processVehicle(event.latLng);
	});
}

var CreationManager = function (onStart, onEnd) {
	var p = {}
	var vehicle = {};
	var markerTitle;

	var placeMarker = function (title, coord, image) {
		var point = {
			position: coord,
			map: MAP,
			title: title + coord.toString(),
			icon: image
		}

		MARKERS.push(new google.maps.Marker(point));
		
		return {
			lat: coord.lat(),
			lng: coord.lng()
		}
	}

	var checkField = function (fieldValue, fieldName, fn) {
		if(fieldValue == null || fieldValue === ''){
			alert(fieldName + ' is a mandatory field.');
			if(fn != null) fn();
			return false;
		}
		return true;
	}

	var stepOne = function (coord) {
		var info = onStart();
		if(!checkField(info.name, 'Vehicle name', info.onInvalidValues)) return;
		vehicle.name = info.name;

		markerTitle = "Vehicle name: " + info.name + "\nPosition: ";
		if(info.situation === 2){
			if(!checkField(info.parkedDuration, 'Duration', info.onInvalidValues)) return;
			vehicle.parkedDuration = parseInt(info.parkedDuration);
			vehicle.start = placeMarker (markerTitle, coord, CAR_IMAGE);
			processVehicle = doNothing;
			onEnd();
			return;
		}

		if(!checkField(info.normalSpeed, 'Normal Speed', info.onInvalidValues)) return;
		vehicle.normalSpeed = parseFloat(info.normalSpeed) * 0.277777778;
		// vehicle.parked = false;
		if(info.situation === 0){
			if(!checkField(info.jamSpeed, 'Jam Speed', info.onInvalidValues)) return;
			vehicle.jamSpeed = parseFloat(info.jamSpeed) * 0.277777778;
			processVehicle = stepTwo;
		}else{
			processVehicle = stepFour;
		}
		vehicle.start = placeMarker (markerTitle, coord, START_IMAGE);
	}

	var stepTwo = function (coord){
		processVehicle = stepThree;
		vehicle.jamStart = placeMarker (markerTitle, coord, SLUG_SIGN_IMAGE);
	}


	var stepThree = function (coord){
		processVehicle = stepFour;
		vehicle.jamEnd = placeMarker (markerTitle, coord, RABBIT_SIGN_IMAGE);
	}


	var stepFour = function (coord){
		processVehicle = doNothing;
		vehicle.end = placeMarker (markerTitle, coord, ARRIVE_IMAGE);
		onEnd();
	}

	var cloneVehicle = function () {
		var clone = {
			id: vehicle.id,
			name: vehicle.name,
			start: vehicle.start,
			jamStart: vehicle.jamStart,
			jamEnd: vehicle.jamEnd,
			end: vehicle.end,
			normalSpeed: vehicle.normalSpeed,
			jamSpeed: vehicle.jamSpeed,
			parkedDuration: vehicle.parkedDuration
		}
		return clone;
	}

	p.getVehicle = function () {
		return vehicle;
	}

	processVehicle = stepOne;

	return p;
}